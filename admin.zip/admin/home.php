<!DOCTYPE html>
<html>
<head>
  <title>web site sederhana</title>
  <link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="login.php">

</head>
<body>
  <header>
    <div class="main">
      <ul>
        <li><a href="home.php" class="active"></a></li>
        <li><a href="service.php"></a></li>
        <li><a href="about.php"></a></li>
      </ul>
    </div>
  </header>
  <div class="title">
    <tr style="color: black;">
    <h3>SELAMAT DATANG</h3>
   
  </div>
  <div class="">
<a href="" class="btn"></a>
</div>
<br></br>
  </body>
  </html>
